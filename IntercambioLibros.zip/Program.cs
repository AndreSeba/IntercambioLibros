using Blazored.LocalStorage;
using IntercambioLibros;
using IntercambioLibros.Services;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using BlazorDownloadFile;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });
builder.Services.AddBlazorDownloadFile();

builder.Services.AddBlazoredLocalStorage();
builder.Services.AddSingleton<ServicioUsuarios>();
builder.Services.AddSingleton<ServicioLibros>();    
builder.Services.AddSingleton<ServicioSolicitudes>();
builder.Services.AddSingleton<SesionService>();
builder.Services.AddSingleton<ServicioNotificaciones>();
builder.Services.AddSingleton<ReconocimientoFacialService>();
builder.Services.AddSingleton<ServicioRese�as>();

await builder.Build().RunAsync();
