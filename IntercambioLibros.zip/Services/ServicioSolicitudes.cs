﻿using IntercambioLibros.Model;

namespace IntercambioLibros.Services
{
    public class ServicioSolicitudes
    {
        public List<SolicitudIntercambio> Solicitudes { get; set; } = new();
        private int contador = 1;

        public void EnviarSolicitud(SolicitudIntercambio solicitud)
        {
            solicitud.Id = contador++;
            Solicitudes.Add(solicitud);
        }

        public List<SolicitudIntercambio> ObtenerSolicitudesPorUsuario(int usuarioId)
        {
            return Solicitudes.Where(s => s.UsuarioSolicitanteId == usuarioId || s.UsuarioDueñoLibroId == usuarioId).ToList();
        }
        public SolicitudIntercambio? ObtenerSolicitudPorId(int id)
        {
            return Solicitudes.FirstOrDefault(s => s.Id == id);
        }

    }
}
