﻿using IntercambioLibros.Model;
using System.Linq;

namespace IntercambioLibros.Services
{
    public class ServicioNotificaciones
    {
        public List<NotificacionIntercambio> Notificaciones { get; set; } = new();
        private int contador = 1;

        public void AgregarNotificacion(NotificacionIntercambio noti)
        {
            noti.Id = contador++;
            Notificaciones.Add(noti);
        }

        public List<NotificacionIntercambio> ObtenerPorUsuario(int usuarioId)
        {
            return Notificaciones.Where(n => n.UsuarioDestinoId == usuarioId).ToList();
        }

        public void MarcarLeido(int notificacionId)
        {
            var noti = Notificaciones.FirstOrDefault(n => n.Id == notificacionId);
            if (noti != null)
            {
                noti.Leido = true;
            }
        }

        // ✅ MÉTODO NUEVO PARA MOSTRAR PUNTO ROJO SI HAY NUEVAS NOTIFICACIONES
        public bool TieneNotificacionesNuevas(int usuarioId)
        {
            return Notificaciones.Any(n => n.UsuarioDestinoId == usuarioId && !n.Leido);
        }
    }
}
