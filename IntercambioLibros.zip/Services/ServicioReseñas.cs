﻿using IntercambioLibros.Model;

namespace IntercambioLibros.Services
{
    public class ServicioReseñas
    {
        private List<Reseña> reseñas = new();

        public void AgregarReseña(Reseña nueva)
        {
            var existe = reseñas.Any(r =>
                r.SolicitudId == nueva.SolicitudId &&
                r.EvaluadorId == nueva.EvaluadorId);
            if (!existe)
                reseñas.Add(nueva);
        }

        public List<Reseña> ObtenerReseñasDeUsuario(int usuarioId)
        {
            return reseñas.Where(r => r.EvaluadoId == usuarioId).ToList();
        }

        public bool YaCalificó(int solicitudId, int evaluadorId)
        {
            return reseñas.Any(r => r.SolicitudId == solicitudId && r.EvaluadorId == evaluadorId);
        }
    }
}
