﻿using IntercambioLibros.Model;

namespace IntercambioLibros.Services
{
    public class ServicioUsuarios
    {
        public List<Usuario> Usuarios { get; set; } = new();
        private int contador = 1;

        public ServicioUsuarios()
        {
            CargarAdminEstatico();
        }

        public void RegistrarUsuario(Usuario usuario)
        {
            usuario.Id = contador++;
            Usuarios.Add(usuario);
        }

        public Usuario? ValidarLogin(string correo, string contraseña)
        {
            return Usuarios.FirstOrDefault(u => u.Correo == correo && u.Contraseña == contraseña);
        }

        private void CargarAdminEstatico()
        {
            // Verificar que no exista ya el admin (por seguridad si reinicias app)
            if (!Usuarios.Any(u => u.Correo == "admin@libros.com"))
            {
                Usuarios.Add(new Usuario
                {
                    Id = contador++,
                    Nombre = "Administrador",
                    Correo = "admin@libros.com",
                    Contraseña = "admin123", // Contraseña fija
                    Telefono = "",
                    Direccion = "",
                    FotoPerfilBase64 = ""
                });
            }
        }
        public Usuario? ObtenerUsuarioPorId(int id)
        {
            return Usuarios.FirstOrDefault(u => u.Id == id);
        }
    }
}
